/*
 * arduino_ultrason.ino - 1 a 3 capteurs HC-SR04, distances en cm sur le port serie
 *
 * Cablage (Arduino Uno / Nano) :
 *   chaque HC-SR04 : VCC -> 5V, GND -> GND, TRIG et ECHO -> broches ci-dessous
 *
 *   capteur  TRIG  ECHO
 *   centre    9     10     <- obligatoire, vers l'avant
 *   gauche    7      8     <- optionnel, incline ~30 deg vers la gauche
 *   droite   11     12     <- optionnel, incline ~30 deg vers la droite
 *
 * Sortie serie (115200 bauds), une ligne toutes les ~60 ms :
 *   "centre,gauche,droite"  en cm, -1 = pas de capteur ou pas d'echo
 *   ex : "87,-1,-1"  (un seul capteur)   "87,143,52"  (trois capteurs)
 *
 * Mettre NB_CAPTEURS au nombre reellement branche.
 */

const int NB_CAPTEURS = 1;                 // 1, 2 ou 3

const int TRIG[3] = {9, 7, 11};           // centre, gauche, droite
const int ECHO[3] = {10, 8, 12};

const unsigned long TIMEOUT_US = 25000;    // 25 ms ~ 4,3 m aller-retour
const int PORTEE_MAX_CM = 400;

long mesurer(int i) {
  digitalWrite(TRIG[i], LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG[i], HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG[i], LOW);
  unsigned long duree = pulseIn(ECHO[i], HIGH, TIMEOUT_US);
  if (duree == 0) return -1;               // pas d'echo dans le delai
  long cm = duree / 58;                    // 343 m/s, aller-retour
  if (cm > PORTEE_MAX_CM) return -1;
  return cm;
}

void setup() {
  Serial.begin(115200);
  for (int i = 0; i < 3; i++) {
    pinMode(TRIG[i], OUTPUT);
    pinMode(ECHO[i], INPUT);
    digitalWrite(TRIG[i], LOW);
  }
}

void loop() {
  long d[3] = {-1, -1, -1};
  for (int i = 0; i < NB_CAPTEURS; i++) {
    d[i] = mesurer(i);
    delay(15);                             // laisse les echos s'eteindre entre capteurs
  }
  Serial.print(d[0]); Serial.print(',');
  Serial.print(d[1]); Serial.print(',');
  Serial.println(d[2]);
  delay(20);
}
