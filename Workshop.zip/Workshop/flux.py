#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
flux.py - lecture du flux video MJPEG du Yanshee (port 8000)

Un thread lit le flux en continu et garde la DERNIERE image JPEG.
Aucune dependance a OpenCV : on decoupe le flux sur les marqueurs JPEG.

TEST
    python3 flux.py IP_ROBOT
        ouvre le flux, detecte le chemin, mesure le debit, enregistre 5 images

USAGE
    from flux import FluxVideo
    with FluxVideo(robot) as flux:
        jpeg = flux.derniere()          # bytes, ou None
        chemin = flux.enregistrer(jpeg, "dossier")
"""

import os
import sys
import threading
import time

import requests

PORT = 8000
CHEMINS_CANDIDATS = ("", "/", "/stream.mjpg", "/?action=stream", "/stream",
                     "/video", "/mjpeg", "/video_feed")
SOI = b"\xff\xd8"          # debut d'image JPEG
EOI = b"\xff\xd9"          # fin d'image JPEG


class FluxVideo:

    def __init__(self, robot, port=PORT, verbeux=True, resolution="640x480"):
        self.robot = robot
        self.resolution = resolution
        self.base = "http://%s:%d" % (robot.ip, port)
        self.verbeux = verbeux
        self.url = None
        self._image = None
        self._horodatage = 0.0
        self._images_lues = 0
        self._arret = threading.Event()
        self._thread = None

    # -- cycle de vie -------------------------------------------------------

    def demarrer(self):
        self.robot.flux_video(True, self.resolution)
        time.sleep(1.5)                       # le serveur met un instant a ouvrir
        self.url = self._detecter_chemin()
        if not self.url:
            if self.verbeux:
                print("[flux] aucun chemin MJPEG trouve sur %s" % self.base)
            return False
        self._thread = threading.Thread(target=self._lire, daemon=True)
        self._thread.start()
        fin = time.time() + 5
        while self._image is None and time.time() < fin:
            time.sleep(0.1)
        if self.verbeux:
            print("[flux] %s -> %s" % (self.url,
                  "premiere image recue" if self._image else "AUCUNE image en 5 s"))
        return self._image is not None

    def arreter(self):
        self._arret.set()
        if self._thread:
            self._thread.join(timeout=2)
        self.robot.flux_video(False)

    def __enter__(self):
        self.demarrer()
        return self

    def __exit__(self, *_):
        self.arreter()

    # -- acces --------------------------------------------------------------

    def derniere(self, age_max_s=3.0):
        """Derniere image JPEG (bytes), ou None si absente ou trop vieille."""
        if self._image is None or time.time() - self._horodatage > age_max_s:
            return None
        return self._image

    def age(self):
        return time.time() - self._horodatage if self._image else None

    @staticmethod
    def enregistrer(jpeg, dossier):
        if not os.path.isdir(dossier):
            os.makedirs(dossier)
        chemin = os.path.join(dossier, "flux_%s.jpg" % time.strftime("%Y%m%d_%H%M%S"))
        with open(chemin, "wb") as fichier:
            fichier.write(jpeg)
        return chemin

    # -- interne ------------------------------------------------------------

    def _detecter_chemin(self):
        for chemin in CHEMINS_CANDIDATS:
            url = self.base + chemin
            try:
                reponse = requests.get(url, stream=True, timeout=4)
                type_contenu = reponse.headers.get("Content-Type", "")
                if self.verbeux:
                    print("[flux] essai %-28s HTTP %s  %s"
                          % (url, reponse.status_code, type_contenu[:40]))
                if reponse.status_code == 200 and (
                        "multipart" in type_contenu or "jpeg" in type_contenu):
                    reponse.close()
                    return url
                reponse.close()
            except requests.RequestException as erreur:
                if self.verbeux:
                    print("[flux] essai %-28s %s" % (url, erreur.__class__.__name__))
        return None

    def _lire(self):
        tampon = b""
        while not self._arret.is_set():
            try:
                with requests.get(self.url, stream=True, timeout=10) as reponse:
                    for morceau in reponse.iter_content(chunk_size=8192):
                        if self._arret.is_set():
                            return
                        tampon += morceau
                        debut = tampon.find(SOI)
                        fin = tampon.find(EOI, debut + 2) if debut >= 0 else -1
                        while debut >= 0 and fin >= 0:
                            self._image = tampon[debut:fin + 2]
                            self._horodatage = time.time()
                            self._images_lues += 1
                            tampon = tampon[fin + 2:]
                            debut = tampon.find(SOI)
                            fin = tampon.find(EOI, debut + 2) if debut >= 0 else -1
                        if len(tampon) > 2_000_000:      # securite : flux corrompu
                            tampon = b""
            except requests.RequestException as erreur:
                if self.verbeux:
                    print("[flux] coupure (%s), reconnexion..." % erreur.__class__.__name__)
                time.sleep(1)


# ---------------------------------------------------------------------------

def test(ip):
    from robot import Yanshee
    robot = Yanshee(ip, gestion_chute=False)
    with FluxVideo(robot) as flux:
        if not flux.derniere(age_max_s=10):
            print("\nEchec. Ouvrez %s dans un navigateur et cherchez l'URL de la"
                  " video (clic droit > copier l'adresse de l'image), puis"
                  " ajoutez son chemin a CHEMINS_CANDIDATS." % flux.base)
            return
        debut = time.time()
        lues_debut = flux._images_lues
        time.sleep(5)
        debit = (flux._images_lues - lues_debut) / (time.time() - debut)
        print("\ndebit : %.1f images/s   taille : %d octets   age : %.2f s"
              % (debit, len(flux.derniere() or b""), flux.age() or 0))
        for i in range(5):
            jpeg = flux.derniere()
            if jpeg:
                print("  ->", flux.enregistrer(jpeg, "exploration"))
            time.sleep(0.5)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    test(sys.argv[1])
