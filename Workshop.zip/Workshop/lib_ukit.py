# -*- coding: utf-8 -*-
"""Remplacant minimal de lib_ukit pour importer YanAPI hors du robot.

YanAPI.py fait `from lib_ukit import lib_send` en tete de fichier, mais ne
s'en sert que dans la classe ukit_controller (modules uKit), que nous
n'utilisons pas. Ce fichier permet l'import sur le portable.
"""


class lib_send:

    @staticmethod
    def lib_send_data_to_uKit(msg):
        raise NotImplementedError("modules uKit non disponibles sur cette machine")

    @staticmethod
    def lib_get_msg_from_uKit(data):
        raise NotImplementedError("modules uKit non disponibles sur cette machine")
