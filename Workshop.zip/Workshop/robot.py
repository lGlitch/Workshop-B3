#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
robot.py v5 - couche d'abstraction pour Yanshee (UBTECH ERHA101)

Calee sur le code source de YanAPI.py :
  - tout est HTTP : yan_api_init(ip) reecrit http://<ip>:9090/v1/
  - sync_play_motion renvoie True/False
  - get_servos_angles exige une liste de noms
  - "head" accepte forward|left|right ; on pilote plutot le servo NeckLR
    (n. 17, plage sure 15-165, runtime 200-4000 ms)
  - open_vision_stream publie un flux MJPEG sur http://<ip>:8000
  - doc interactive de l'API : http://<ip>:9090/v1/ui

USAGE
    python3 robot.py [IP] COMMANDE [ARGS]
        IP omise -> 127.0.0.1 (execution sur le robot)
        IP donnee -> pilotage a distance depuis le portable

COMMANDES
    calibrer         enregistre la posture debout  <-- A FAIRE EN 1er
    etat             batterie, gyro, mode, detecteur de chute
    reveil           sort du mode economie d'energie (erreur code 8)
    essai NOM [DIRECTION] [VITESSE]
    tete             test du servo de la tete
    regarde          panoramique tete + 3 photos
    marche [V] [S] [P] [B] [M]  marche continue : vitesse V, S s, period P, bras B, mode M (gait|motion)
    servos           angles des 17 servos par paires gauche/droite (derive apres chute)
    stoptest         verifie que l'ordre d'arret stoppe vraiment le robot
    flux             ouvre le flux video et affiche son URL
    teleop           pilotage clavier + collecte du dataset

TELEOP (clavier AZERTY)
    Z avancer     S reculer     Q tourner a gauche    D tourner a droite
    A tete gauche E tete droite C tete au centre      W panoramique
    P photo       R reset       ESPACE stop           X quitter

SUR LE PORTABLE
    dossier contenant : robot.py, YanAPI.py (copie du robot), lib_ukit.py
    pip install requests nest_asyncio
    python3 robot.py 10.42.0.23 etat
"""

import csv
import json
import math
import os
import re
import sys
import time

import YanAPI

# YanAPI appelle requests.get/post/put/delete sans timeout : un robot
# injoignable bloque chaque appel ~30 s. On impose un plafond global.
import requests.api as _requests_api
_requete_originale = _requests_api.request


def _requete_avec_timeout(*args, **kwargs):
    kwargs.setdefault("timeout", 5)
    return _requete_originale(*args, **kwargs)


_requests_api.request = _requete_avec_timeout


def _verifier_joignable(ip, port=9090, delai=2.0):
    """Echoue vite et clairement si le robot n'est pas sur le reseau."""
    import socket
    try:
        with socket.create_connection((ip, port), timeout=delai):
            return True
    except OSError as erreur:
        raise SystemExit(
            "\nRobot injoignable sur %s:%d (%s).\n"
            "  - meme reseau ? comparez 'hostname -I' (robot) et 'ip a' (PC)\n"
            "  - reseau d'ecole avec isolation des clients ? passez sur un\n"
            "    point d'acces a vous (telephone ou PC)\n"
            "  - ping %s depuis le robot vers ce PC pour confirmer\n"
            % (ip, port, erreur, ip))


# ---------------------------------------------------------------------------
# Mouvements reels (valeurs de RobotBuiltInMotion, espaces compris)
# ---------------------------------------------------------------------------

MOUVEMENTS = {
    "avance":     dict(name="walk", direction="forward"),
    "recule":     dict(name="walk", direction="backward"),
    "gauche":     dict(name="turn around", direction="left"),
    "droite":     dict(name="turn around", direction="right"),
    "pas_gauche": dict(name="walk", direction="left"),
    "pas_droite": dict(name="walk", direction="right"),
    "repos":      dict(name="reset"),
    "accroupi":   dict(name="crouch"),
    "salue":      dict(name="wave", direction="right"),
    "incline":    dict(name="bow"),
}

VITESSE = "slow"

SERVO_TETE = "NeckLR"
TOUS_LES_SERVOS = [
    "RightShoulderRoll", "RightShoulderFlex", "RightElbowFlex",
    "LeftShoulderRoll", "LeftShoulderFlex", "LeftElbowFlex",
    "RightHipLR", "RightHipFB", "RightKneeFlex", "RightAnkleFB", "RightAnkleUD",
    "LeftHipLR", "LeftHipFB", "LeftKneeFlex", "LeftAnkleFB", "LeftAnkleUD",
    "NeckLR",
]
TETE = {"tete_gauche": 60, "tete_centre": 90, "tete_droite": 120}
TETE_DUREE_MS = 400            # borne SDK : 200 a 4000

SEUIL_BATTERIE = 20
MAX_ACTIONS = 300
SEUIL_CHUTE_DEG = 60           # inclinaison (deg) vs posture debout calibree
FICHIER_CALIBRATION = "calibration.json"
DOSSIER_DATASET = "dataset"
PORT_FLUX = 8000


# ---------------------------------------------------------------------------
# Dialogue avec l'API
# ---------------------------------------------------------------------------

class RobotIndisponible(Exception):
    """Levee (mode strict) quand un garde-fou refuse l'action."""


def _appeler(nom_fonction, *args, **kwargs):
    fonction = getattr(YanAPI, nom_fonction, None)
    if fonction is None:
        print("[warn] %s : fonction absente" % nom_fonction)
        return None
    try:
        return fonction(*args, **kwargs)
    except Exception as erreur:
        print("[warn] %s : %s" % (nom_fonction, erreur))
        return None


def _charge_utile(reponse):
    """'data' de l'enveloppe {data, msg, code}, ou None si erreur."""
    if not isinstance(reponse, dict):
        return None
    if reponse.get("code") not in (0, None):
        return None
    return reponse.get("data")


def _nombre(reponse):
    if isinstance(reponse, (int, float)):
        return float(reponse)
    donnees = _charge_utile(reponse)
    if isinstance(donnees, (int, float)):
        return float(donnees)
    if isinstance(donnees, dict):
        for valeur in donnees.values():
            if isinstance(valeur, (int, float)):
                return float(valeur)
    return None


def _resume(reponse):
    if isinstance(reponse, bool):
        return "OK" if reponse else "ECHEC"
    if isinstance(reponse, dict):
        return "code=%s msg=%s" % (reponse.get("code"), reponse.get("msg"))
    return repr(reponse)


# ---------------------------------------------------------------------------
# La classe
# ---------------------------------------------------------------------------

class Yanshee:

    def __init__(self, ip="127.0.0.1", verbeux=True, gestion_chute=True,
                 langue="en", strict=False):
        """
        strict=False : les garde-fous avertissent (teleop, un humain regarde)
        strict=True  : les garde-fous bloquent (mode autonome)
        """
        self.ip = ip
        self.verbeux = verbeux
        self.strict = strict
        self.actions = 0
        self.mode_marche = "gait"      # "gait" (generateur STM32) ou "motion" (animation walk)
        self._calibration_signalee = False
        _verifier_joignable(ip)
        YanAPI.yan_api_init(ip)
        self.reference_debout = self._charger_calibration()
        if langue:
            _appeler("set_robot_language", langue)
        if gestion_chute:
            _appeler("set_robot_fall_management_state", True)
        if self.verbeux:
            print("[ok] %s - batterie %s%% - strict=%s"
                  % (ip, self.batterie(), strict))

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.stop()

    # -- etat ---------------------------------------------------------------

    def batterie(self):
        return _nombre(_appeler("get_robot_battery_value"))

    def cap(self):
        """Cap (lacet) en degres d'apres l'IMU, ou None."""
        m = self.gyro()
        if not m or m.get("euler-z") is None:
            return None
        return float(m["euler-z"])

    def gyro(self):
        donnees = _charge_utile(_appeler("get_sensors_gyro"))
        if isinstance(donnees, dict):
            mesures = donnees.get("gyro")
            if isinstance(mesures, list) and mesures:
                return mesures[0]
        return None

    def gravite(self):
        """Vecteur gravite (accel-x, accel-y, accel-z) en g, ou None."""
        mesures = self.gyro()
        if not mesures:
            return None
        try:
            return (float(mesures["accel-x"]), float(mesures["accel-y"]),
                    float(mesures["accel-z"]))
        except (KeyError, TypeError, ValueError):
            return None

    def inclinaison(self):
        """Angle en degres entre la gravite actuelle et la reference debout.

        On ne suppose plus quel axe de l'IMU est vertical : on mesure l'ecart
        avec la posture debout enregistree par 'robot.py calibrer'. Sans
        calibration, renvoie None.
        """
        if self.reference_debout is None:
            return None
        actuel = self.gravite()
        if actuel is None:
            return None
        ref = self.reference_debout
        produit = sum(a * b for a, b in zip(actuel, ref))
        norme = (math.sqrt(sum(a * a for a in actuel))
                 * math.sqrt(sum(b * b for b in ref)))
        if norme == 0:
            return None
        cosinus = max(-1.0, min(1.0, produit / norme))
        return math.degrees(math.acos(cosinus))

    def est_tombe(self):
        """Vrai si le robot est incline de plus de SEUIL_CHUTE_DEG par
        rapport a sa posture debout calibree. Sans calibration : False."""
        angle = self.inclinaison()
        if angle is None:
            if not self._calibration_signalee:
                print("[avert] pas de calibration : detection de chute inactive"
                      " (lancez 'robot.py calibrer' robot debout)")
                self._calibration_signalee = True
            return False
        return angle > SEUIL_CHUTE_DEG

    def calibrer(self, duree_s=3.0):
        """Enregistre la gravite moyenne, robot DEBOUT et immobile."""
        echantillons = []
        fin = time.time() + duree_s
        while time.time() < fin:
            g = self.gravite()
            if g:
                echantillons.append(g)
            time.sleep(0.1)
        if len(echantillons) < 5:
            print("[erreur] pas assez de mesures du gyro")
            return None
        moyenne = tuple(sum(e[i] for e in echantillons) / len(echantillons)
                        for i in range(3))
        with open(FICHIER_CALIBRATION, "w") as fichier:
            json.dump({"reference_debout": moyenne,
                       "date": time.strftime("%Y-%m-%d %H:%M:%S")}, fichier)
        self.reference_debout = moyenne
        print("[ok] reference debout = (%.3f, %.3f, %.3f) g, %d mesures, -> %s"
              % (moyenne + (len(echantillons), FICHIER_CALIBRATION)))
        return moyenne

    def _charger_calibration(self):
        try:
            with open(FICHIER_CALIBRATION) as fichier:
                ref = json.load(fichier)["reference_debout"]
                return tuple(float(v) for v in ref)
        except (OSError, KeyError, ValueError, TypeError):
            return None

    def capteurs(self):
        donnees = _charge_utile(_appeler("get_sensors_list"))
        return donnees.get("sensors", []) if isinstance(donnees, dict) else []

    def distance(self):
        return _nombre(_appeler("get_sensors_ultrasonic_value"))

    def angle_tete(self):
        """Angle courant du servo NeckLR (data = {"NeckLR": 90})."""
        donnees = _charge_utile(_appeler("get_servos_angles", [SERVO_TETE]))
        if isinstance(donnees, dict):
            return donnees.get(SERVO_TETE)
        return None

    # -- mode veille ----------------------------------------------------------

    def mode(self):
        """{'energy_saving_mode': bool, 'calibration_mode': bool} ou None."""
        return _charge_utile(_appeler("get_robot_mode"))

    def en_veille(self):
        m = self.mode()
        return bool(m and m.get("energy_saving_mode"))

    def reveiller(self):
        """Tente de sortir du mode economie d'energie (erreur code 8).

        Le SDK n'a pas de setter documente : on essaie ce qui est plausible
        et on affiche les reponses pour savoir ce qui a marche.
        """
        print("[veille] mode avant : %s" % self.mode())
        if not self.en_veille():
            return True

        # 1) remettre tous les servos en mode "work"
        r = _appeler("set_servos_mode", "work", TOUS_LES_SERVOS)
        print("[veille] set_servos_mode(work) -> %s" % _resume(r))

        # 2) PUT sur l'endpoint mode (non documente dans le SDK, peut-etre
        #    present dans le Swagger : verifiez http://IP:9090/v1/ui)
        try:
            import requests
            rep = requests.put(YanAPI.basic_url + "devices/mode",
                               json={"energy_saving_mode": False},
                               headers=YanAPI.headers, timeout=5)
            print("[veille] PUT devices/mode -> HTTP %s %s"
                  % (rep.status_code, rep.text[:120]))
        except Exception as erreur:
            print("[veille] PUT devices/mode -> %s" % erreur)

        # 3) un mouvement neutre, parfois suffisant pour reveiller
        r = _appeler("sync_play_motion", name="reset", speed="slow", repeat=1)
        print("[veille] reset -> %s" % _resume(r))

        time.sleep(1)
        print("[veille] mode apres : %s" % self.mode())
        return not self.en_veille()

    # -- garde-fous ---------------------------------------------------------

    def _garde_fou(self, message):
        if self.strict:
            raise RobotIndisponible(message)
        print("[avert] %s" % message)

    def _autoriser(self):
        if self.actions >= MAX_ACTIONS:
            self._garde_fou("quota de %d actions atteint" % MAX_ACTIONS)
        niveau = self.batterie()
        if niveau is not None and niveau < SEUIL_BATTERIE:
            self._garde_fou("batterie a %s%%" % niveau)
        if self.est_tombe():
            self._garde_fou("le robot semble au sol (inclinaison %.0f deg)"
                            % (self.inclinaison() or 0))
        self.actions += 1

    # -- actions ------------------------------------------------------------

    def joue(self, cle, repetitions=1, vitesse=None):
        if cle not in MOUVEMENTS:
            raise ValueError("mouvement inconnu : %s" % cle)
        self._autoriser()
        parametres = dict(MOUVEMENTS[cle])
        parametres.setdefault("direction", "")
        parametres["speed"] = vitesse or VITESSE
        parametres["repeat"] = repetitions
        reponse = _appeler("sync_play_motion", **parametres)
        if self.verbeux:
            print("[action] %-11s -> %s" % (cle, _resume(reponse)))
        if reponse is not True and self.en_veille():
            print("[action] refuse : robot en mode economie d'energie"
                  " -> robot.py reveil, ou appui court sur le bouton poitrine")
        return reponse is True

    def avance(self, pas=1):
        mm = self.distance()
        if mm is not None and mm < 250:
            print("[stop] obstacle a %d mm" % mm)
            return False
        return self.joue("avance", pas)

    def recule(self, pas=1):
        return self.joue("recule", pas)

    def tourne(self, sens, pas=1):
        """sens : 'gauche' ou 'droite'."""
        return self.joue(sens, pas)

    def regarde(self, cle="tete_centre"):
        """Oriente la tete via le servo NeckLR, corps immobile."""
        angle = TETE[cle]
        reponse = _appeler("set_servos_angles", {SERVO_TETE: angle}, TETE_DUREE_MS)
        if self.verbeux:
            print("[tete]   %-11s %3d deg -> %s" % (cle, angle, _resume(reponse)))
        time.sleep(TETE_DUREE_MS / 1000.0 + 0.3)
        return reponse

    def regarde_autour(self, dossier=DOSSIER_DATASET):
        """gauche / centre / droite, une photo a chaque station."""
        images = {}
        for cle, etiquette in (("tete_gauche", "gauche"),
                               ("tete_centre", "centre"),
                               ("tete_droite", "droite")):
            self.regarde(cle)
            images[etiquette] = self.photo(dossier)
        self.regarde("tete_centre")
        return images

    # -- marche continue (gait) : asynchrone, le robot marche jusqu'a stop --

    def marche(self, vitesse=2, lateral=0, periode=1, maintien=False, bras=True):
        """Demarre ou modifie la marche continue.

        vitesse : -5..5 (avant/arriere), lateral : -5..5 (pas de cote),
        periode : 1..5, bras : balancement des bras (param 'wave' du gait).
        LAISSER bras=True : sans balancement, le generateur de marche derive
        en arc de cercle (constate sur cet exemplaire).
        maintien=True : reemission periodique de l'ordre, sans quota ni trace.
        self.mode_marche = "gait"   -> generateur de marche du STM32
                         = "motion" -> animation integree 'walk' repetee
        Renvoie immediatement ; le robot marche jusqu'a marche_stop().
        """
        if not maintien:
            self._autoriser()
        vitesse = max(-5, min(5, int(vitesse)))
        if self.mode_marche == "motion":
            return self._marche_motion(vitesse, maintien)
        lateral = max(-5, min(5, int(lateral)))
        periode = max(1, min(5, int(periode)))
        reponse = _appeler("control_motion_gait", speed_v=vitesse, speed_h=lateral,
                           steps=0, period=periode, wave=bool(bras))
        if self.verbeux and not maintien:
            print("[marche] gait v=%d h=%d p=%d bras=%s -> %s"
                  % (vitesse, lateral, periode, bool(bras), _resume(reponse)))
        ok = isinstance(reponse, dict) and reponse.get("code") == 0
        if not ok and self.en_veille():
            print("[marche] refuse : mode economie d'energie")
        return ok

    VITESSES_MOTION = {1: "very slow", 2: "slow", 3: "normal", 4: "fast", 5: "very fast"}

    def _marche_motion(self, vitesse, maintien=False):
        """Marche continue par l'animation integree 'walk', repetee 100 fois.

        C'est la marche des tests 'essai' et du tour par tour : symetrique,
        bras balances, et enregistree AVEC les particularites du robot, donc
        moins sensible a la calibration que le generateur de marche du STM32.
        """
        if maintien and self.en_marche():
            return True                            # deja en cours, rien a faire
        direction = "forward" if vitesse >= 0 else "backward"
        vitesse_txt = self.VITESSES_MOTION[max(1, min(5, abs(vitesse) or 2))]
        reponse = _appeler("start_play_motion", name="walk", direction=direction,
                           speed=vitesse_txt, repeat=100)
        ok = isinstance(reponse, dict) and reponse.get("code") == 0
        if self.verbeux and not maintien:
            print("[marche] walk %s %s x100 -> %s" % (direction, vitesse_txt, _resume(reponse)))
        if not ok and self.en_veille():
            print("[marche] refuse : mode economie d'energie")
        return ok

    def marche_stop(self, se_relever=True):
        """Arrete la marche.

        motion : stop_play_motion, le robot finit sa pose et s'arrete.
        gait   : period=0 est l'arret documente ; s'il n'a pas pris effet en
                 0.6 s on force exit_motion_gait (plus lent : il se redresse).
                 se_relever=True quitte de toute facon le mode marche,
                 necessaire avant un mouvement comme 'turn around'.
        """
        if self.mode_marche == "motion":
            _appeler("stop_play_motion")
            return
        _appeler("control_motion_gait", speed_v=0, speed_h=0, steps=0, period=0)
        if not se_relever:
            time.sleep(0.6)
            if self.marche_etat() == 2:            # marche toujours
                if self.verbeux:
                    print("[marche] period=0 sans effet -> exit_motion_gait")
                se_relever = True
        if se_relever:
            _appeler("exit_motion_gait")
            self._attendre_gait_idle()

    def marche_etat(self):
        """gait : 0..8 (8 = inactif). motion : 'idle' / 'run' / ..."""
        if self.mode_marche == "motion":
            donnees = _charge_utile(_appeler("get_current_motion_play_state"))
            return donnees.get("status") if isinstance(donnees, dict) else None
        donnees = _charge_utile(_appeler("get_motion_gait_state"))
        return donnees.get("status") if isinstance(donnees, dict) else None

    def en_marche(self):
        etat = self.marche_etat()
        if self.mode_marche == "motion":
            return etat is not None and etat != "idle"
        return etat in (0, 1, 2)

    def _attendre_gait_idle(self, delai_s=6.0):
        fin = time.time() + delai_s
        while time.time() < fin:
            if self.marche_etat() in (8, None):
                return True
            time.sleep(0.3)
        return False

    def repos(self):
        return self.joue("repos")

    def stop(self):
        _appeler("stop_play_motion")
        _appeler("exit_motion_gait")

    # -- perception et parole -----------------------------------------------

    def photo(self, dossier=DOSSIER_DATASET):
        """Prend une photo, la rapatrie, renvoie son chemin local."""
        if not os.path.isdir(dossier):
            os.makedirs(dossier)
        donnees = _charge_utile(_appeler("take_vision_photo", resolution="640x480"))
        nom = donnees.get("name") if isinstance(donnees, dict) else None
        if not nom:
            return None
        _appeler("get_vision_photo", nom, dossier + os.sep)   # savePath doit finir par /
        return os.path.join(dossier, nom)

    def flux_video(self, ouvrir=True, resolution="640x480"):
        """Demarre (ou arrete) le flux MJPEG et renvoie son URL."""
        if ouvrir:
            _appeler("open_vision_stream", resolution=resolution)
        else:
            _appeler("close_vision_stream")
        return "http://%s:%d" % (self.ip, PORT_FLUX)

    def dis(self, texte):
        return _appeler("sync_do_tts", tts=texte, interrupt=True)

    def yeux(self, couleur="blue", mode="on"):
        """LED des yeux (type camera) : red | green | blue ; on | off | blink."""
        return _appeler("set_robot_led", "camera", couleur, mode)

    def bouton(self, couleur="white", mode="on"):
        """LED du bouton poitrine : white/red/green/blue/yellow/purple/cyan ;
        on/off/blink/breath."""
        return _appeler("set_robot_led", "button", couleur, mode)


# ---------------------------------------------------------------------------
# Commandes
# ---------------------------------------------------------------------------

def cmd_etat(robot):
    print("batterie :", robot.batterie(), "%")
    print("capteurs :", robot.capteurs())
    print("ultrason :", robot.distance(), "(None = module non branche)")
    print("tete     :", robot.angle_tete(), "deg")
    print("doc API  : http://%s:9090/v1/ui" % robot.ip)
    print("calib    :", "oui" if robot.reference_debout else "NON -> robot.py calibrer")
    print("mode     :", robot.mode())
    print("\nsurveillance 10 s (penchez, couchez, redressez le robot) :")
    for _ in range(10):
        g = robot.gravite() or (0, 0, 0)
        angle = robot.inclinaison()
        print("  accel x=%6.2f y=%6.2f z=%6.2f   inclinaison=%s   au sol=%s"
              % (g + ("%3.0f deg" % angle if angle is not None else "  n/a",
                      robot.est_tombe())))
        time.sleep(1)


def cmd_reveil(robot):
    if robot.reveiller():
        print("\nrobot reveille. Test :")
        robot.joue("repos")
    else:
        print("\ntoujours en veille : appui court sur le bouton poitrine,"
              " puis relance. Sinon eteindre/rallumer.")


def cmd_calibrer(robot):
    print("Mets le robot DEBOUT sur ses pieds, immobile, et ne le touche plus.")
    input("Entree pour enregistrer la posture de reference (3 s) ")
    if robot.calibrer() is not None:
        print("\nverification : penche-le maintenant, l'inclinaison doit grimper.")
        for _ in range(8):
            print("  inclinaison = %5.1f deg   au sol=%s"
                  % (robot.inclinaison() or 0, robot.est_tombe()))
            time.sleep(1)


def cmd_essai(robot, arguments):
    nom = arguments[0] if arguments else "reset"
    direction = arguments[1] if len(arguments) > 1 else ""
    vitesse = arguments[2] if len(arguments) > 2 else VITESSE
    print("\nname=%r direction=%r speed=%r" % (nom, direction, vitesse))
    input("Robot au sol, main au-dessus. Entree pour lancer ")
    print("reponse :", _resume(_appeler("sync_play_motion", name=nom,
                                        direction=direction, speed=vitesse,
                                        repeat=1)))


def cmd_tete(robot):
    print("angle actuel :", robot.angle_tete())
    input("Entree pour tester gauche / centre / droite ")
    for cle in ("tete_gauche", "tete_centre", "tete_droite", "tete_centre"):
        robot.regarde(cle)
        print("   lu :", robot.angle_tete())


def cmd_regarde(robot):
    print("photos :", robot.regarde_autour())


PAIRES_SERVOS = [
    ("RightShoulderRoll", "LeftShoulderRoll"), ("RightShoulderFlex", "LeftShoulderFlex"),
    ("RightElbowFlex", "LeftElbowFlex"),
    ("RightHipLR", "LeftHipLR"), ("RightHipFB", "LeftHipFB"),
    ("RightKneeFlex", "LeftKneeFlex"), ("RightAnkleFB", "LeftAnkleFB"),
    ("RightAnkleUD", "LeftAnkleUD"),
]


def cmd_servos(robot):
    """Angles des 17 servos, par paires droite/gauche, pour reperer une
    asymetrie apres une chute (dérive en marchant). Robot en posture 'reset'."""
    print("Mise en posture de reference (reset)...")
    robot.joue("repos")
    time.sleep(1.5)
    donnees = _charge_utile(_appeler("get_servos_angles", TOUS_LES_SERVOS)) or {}
    print("\n%-20s %6s   %-20s %6s   %s" % ("droite", "angle", "gauche", "angle", "ecart a la symetrie"))
    for d, g in PAIRES_SERVOS:
        ad, ag = donnees.get(d), donnees.get(g)
        if ad is None or ag is None:
            print("%-20s %6s   %-20s %6s" % (d, ad, g, ag))
            continue
        # les articulations symetriques sont en miroir autour de 90 :
        # (ad - 90) devrait valoir -(ag - 90), donc ad + ag ~ 180
        ecart = (ad + ag) - 180
        alerte = "  <-- suspect" if abs(ecart) >= 6 else ""
        print("%-20s %6s   %-20s %6s   %+4d%s" % (d, ad, g, ag, ecart, alerte))
    print("%-20s %6s" % ("NeckLR", donnees.get("NeckLR")))
    print("\nLecture : un ecart de 0 a +/-3 est normal. Une paire de hanche ou de"
          " cheville a +/-6 ou plus explique une marche en arc de cercle ; la"
          " calibration des servos se fait dans l'appli Yanshee (Reglages > Calibration).")


def cmd_marche(robot, arguments):
    """robot.py IP marche [VITESSE] [DUREE_S] [PERIODE] [BRAS 0/1] [MODE gait|motion]

    Diagnostic : la marche s'arrete-t-elle toute seule ? On lit l'etat toutes
    les 0,5 s ; 2 = marche, 3 = pas max atteints, 5 = arretee, 8 = inactive."""
    vitesse = int(arguments[0]) if arguments else 2
    duree = float(arguments[1]) if len(arguments) > 1 else 5.0
    periode = int(arguments[2]) if len(arguments) > 2 else 1
    bras = bool(int(arguments[3])) if len(arguments) > 3 else True
    robot.mode_marche = arguments[4] if len(arguments) > 4 else "gait"
    print("\nMarche continue [%s] vitesse %d, period=%d, bras=%s, pendant %.0f s. Robot au sol, main prete."
          % (robot.mode_marche, vitesse, periode, "balancement" if bras else "immobiles", duree))
    input("Entree pour lancer ")
    cap_depart = robot.cap()
    debut = time.time()
    robot.marche(vitesse, periode=periode, bras=bras)
    fin = debut + duree
    a_marche = False
    while time.time() < fin:
        etat = robot.marche_etat()
        print("  t=%5.1fs  etat gait = %s   inclinaison = %s deg"
              % (time.time() - debut, etat, round(robot.inclinaison() or 0)))
        if etat == 2 or (robot.mode_marche == "motion" and etat not in (None, "idle")):
            a_marche = True
        elif a_marche and (etat in (3, 5, 8) or etat == "idle"):
            print("\n  >>> la marche s'est arretee TOUTE SEULE apres %.1f s (etat %s)"
                  % (time.time() - debut, etat))
            break
        time.sleep(0.5)
    robot.marche_stop()
    print("arret demande, etat gait =", robot.marche_etat())
    time.sleep(1.0)
    cap_arrivee = robot.cap()
    if cap_depart is not None and cap_arrivee is not None:
        derive = (cap_arrivee - cap_depart + 180) % 360 - 180
        print("\nCAP : depart %.0f deg, arrivee %.0f deg  ->  derive %+.0f deg en %.0f s (%s)"
              % (cap_depart, cap_arrivee, derive, duree,
                 "a droite" if derive > 0 else "a gauche" if derive < 0 else "droit"))
        print("(le signe depend de la convention de l'IMU : notez simplement si le"
              " chiffre a le meme signe que ce que vous voyez)")


def cmd_stoptest(robot):
    """Verifie que l'ordre d'arret (period=0) stoppe vraiment le robot."""
    print("\nMarche 3 s, puis ordre d'arret period=0, puis observation 3 s.")
    input("Robot au sol, main prete. Entree ")
    robot.marche(2)
    time.sleep(3)
    t = time.time()
    _appeler("control_motion_gait", speed_v=0, speed_h=0, steps=0, period=0)
    for _ in range(6):
        print("  +%.1fs  etat gait = %s" % (time.time() - t, robot.marche_etat()))
        time.sleep(0.5)
    etat = robot.marche_etat()
    print("\nVERDICT :", "period=0 arrete le robot (etat %s)" % etat if etat != 2
          else "period=0 NE STOPPE PAS (etat 2) -> l'arret passera par exit_motion_gait")
    robot.marche_stop()


def cmd_flux(robot):
    url = robot.flux_video(True)
    print("flux MJPEG demarre. Ouvrez dans un navigateur :", url)
    print("(si la page est vide, essayez %s/stream.mjpg ou %s/?action=stream)"
          % (url, url))
    input("Entree pour arreter le flux ")
    robot.flux_video(False)


def _lire_touche():
    import termios
    import tty
    descripteur = sys.stdin.fileno()
    ancien = termios.tcgetattr(descripteur)
    try:
        tty.setraw(descripteur)
        return sys.stdin.read(1)
    finally:
        termios.tcsetattr(descripteur, termios.TCSADRAIN, ancien)


TOUCHES_MOUVEMENT = {"z": "avance", "s": "recule", "q": "gauche",
                     "d": "droite", "r": "repos"}
TOUCHES_TETE = {"a": "tete_gauche", "e": "tete_droite", "c": "tete_centre"}


def cmd_teleop(robot):
    if not os.path.isdir(DOSSIER_DATASET):
        os.makedirs(DOSSIER_DATASET)
    chemin = os.path.join(DOSSIER_DATASET, "journal.csv")
    nouveau = not os.path.exists(chemin)
    print(__doc__[__doc__.index("TELEOP"):__doc__.index("SUR LE PORTABLE")])
    print("Journal : %s\n" % chemin)

    with open(chemin, "a") as fichier:
        journal = csv.writer(fichier)
        if nouveau:
            journal.writerow(["horodatage", "image", "action", "batterie"])
        while True:
            touche = _lire_touche().lower()
            print("[touche] %r" % touche)
            if touche == "x":
                return
            if touche == " ":
                robot.stop()
                continue
            if touche == "w":
                print("panoramique :", robot.regarde_autour())
                continue
            if touche == "p":
                print("photo :", robot.photo())
                continue
            if touche in TOUCHES_TETE:
                robot.regarde(TOUCHES_TETE[touche])
                continue
            if touche not in TOUCHES_MOUVEMENT:
                continue
            action = TOUCHES_MOUVEMENT[touche]
            image = robot.photo()
            if robot.joue(action):
                journal.writerow([time.strftime("%Y-%m-%d %H:%M:%S"),
                                  image, action, robot.batterie()])
                fichier.flush()


def main():
    arguments = sys.argv[1:]
    ip = "127.0.0.1"
    if arguments and re.match(r"^\d{1,3}(\.\d{1,3}){3}$", arguments[0]):
        ip = arguments.pop(0)
    commande = arguments.pop(0) if arguments else "etat"

    robot = Yanshee(ip=ip, gestion_chute=(commande not in ("etat", "calibrer")),
                    strict=False)
    try:
        {"etat": lambda: cmd_etat(robot),
         "calibrer": lambda: cmd_calibrer(robot),
         "reveil": lambda: cmd_reveil(robot),
         "essai": lambda: cmd_essai(robot, arguments),
         "tete": lambda: cmd_tete(robot),
         "regarde": lambda: cmd_regarde(robot),
         "flux": lambda: cmd_flux(robot),
         "marche": lambda: cmd_marche(robot, arguments),
         "servos": lambda: cmd_servos(robot),
         "stoptest": lambda: cmd_stoptest(robot),
         "teleop": lambda: cmd_teleop(robot),
         }.get(commande, lambda: print(__doc__))()
    except KeyboardInterrupt:
        print("\ninterrompu")
    finally:
        robot.stop()


if __name__ == "__main__":
    main()
