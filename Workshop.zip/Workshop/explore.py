#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
explore.py v5 - une IA de vision pilote le Yanshee

ARCHITECTURE (mode continu)
  reflexe.py   thread a ~10 Hz : profondeur monoculaire, FREINE seul devant un
               obstacle, sans modele de langage. ACTIF PAR DEFAUT.
  modele VLM   ~1-3 s par decision : choisit ou aller (avance/gauche/droite/
               recule/stop) en voyant l'image ET les distances du reflexe.
  veto         si le modele dit "avance" alors que le reflexe est bloque, le
               code tourne du cote le plus degage.

MODES
  tour par tour (defaut)   image -> modele -> un pas / un pivot
  continu (--continu)      le robot marche pendant que le modele reflechit

PREREQUIS
  ollama pull qwen2.5vl ; ollama pull qwen2.5vl:3b ; ollama serve
  pip install torch transformers pillow numpy       (reflexe)
  python3 reflexe.py --telecharger                  (une fois, AVEC internet)
  python3 robot.py IP calibrer                      (posture debout)

USAGE
  python3 explore.py IP [--continu] [--rapide] [--vitesse N] [--seuil M]
                        [--sans-reflexe] [--photos] [--confirmer] [--parle]
                        [--ollama URL] [--modele NOM] [--resolution WxH]
                        [--decisions N]

  Progression :
    python3 explore.py IP --confirmer                 # valider les decisions
    python3 explore.py IP --continu --rapide          # marche + reflexe

Fichiers requis a cote : robot.py, flux.py, reflexe.py, capteurs.py, YanAPI.py, lib_ukit.py
"""

import argparse
import base64
import csv
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor

import requests

from robot import Yanshee, RobotIndisponible

try:
    from capteurs import Capteurs, Gaz, Chaleur, Vapeur, DETECTEURS
except ImportError:
    Capteurs = Gaz = None

try:
    from reflexe import Reflexe, Ultrason, ModeleAbsent
    ERREUR_REFLEXE = None
except ImportError as erreur_import:          # torch / transformers absents
    Reflexe = Ultrason = None
    ModeleAbsent = Exception
    ERREUR_REFLEXE = str(erreur_import)

ACTIONS = ("avance", "gauche", "droite", "recule", "stop")
ZONES = ("gauche", "centre", "droite")
AGE_IMAGE_MAX_S = 3.0
DELAI_MODELE_S = 4.0
ROTATIONS_AVANT_RECUL = 3
ROTATIONS_AVANT_DEMI_TOUR = 6
DUREE_RECUL_S = 1.0          # recul a l'aveugle : pas de camera derriere
DOSSIER = "exploration"

# La reponse est CONTRAINTE par ce schema (Ollama structured outputs) :
# le modele ne peut plus recopier un exemple ni inventer une action.
SCHEMA = {
    "type": "object",
    "properties": {
        "libre":  {"type": "string", "enum": list(ZONES)},
        "action": {"type": "string", "enum": list(ACTIONS)},
        "raison": {"type": "string"},
    },
    "required": ["libre", "action", "raison"],
}

CONSIGNE_PAS = """Tu guides un petit robot humanoide de 37 cm qui se promene dans une piece.
La photo vient de sa camera, a hauteur de genou humain. Dernieres actions : {historique}.
{capteur}
Reponds avec trois champs.
"libre" : la zone ou le sol est le plus degage (gauche, centre ou droite).
"action" :
- avance : le choix normal, tant que le passage devant reste ouvert
{options}
- recule : seulement si le robot est coince, sans issue a gauche ni a droite
- stop : seulement si tu vois un escalier, une personne tres proche ou un cable au sol
"raison" : quinze mots maximum sur ce que tu vois (meubles, porte, sol, lumiere),
sans repeter l'action.
Une rotation ne se justifie que si le passage devant se referme, ou si une
ouverture nettement plus grande est visible d'un cote."""

CONSIGNE_CONTINU = """Tu guides un petit robot humanoide de 37 cm qui se promene dans une piece.
Il marche vers l'avant. La photo vient de sa camera, a hauteur de genou humain.
Dernieres actions : {historique}.
{capteur}
Un capteur de profondeur freine automatiquement le robot avant tout contact.
Reponds avec trois champs.
"libre" : la zone ou le sol est le plus degage (gauche, centre ou droite).
"action" :
- avance : le choix normal, tant que le passage devant reste ouvert
{options}
- recule : seulement si le capteur indique un obstacle devant ET des deux cotes
- stop : seulement si tu vois un escalier, une personne tres proche ou un cable au sol
"raison" : quinze mots maximum sur ce que tu vois (meubles, porte, sol, lumiere),
sans repeter l'action.
Une rotation ne se justifie que si le passage devant se referme, ou si une
ouverture nettement plus grande est visible d'un cote."""

OPTION_GAUCHE = "- gauche : pivoter vers la gauche"
OPTION_DROITE = "- droite : pivoter vers la droite"


# ---------------------------------------------------------------------------
# Le modele
# ---------------------------------------------------------------------------

class Cerveau:

    def __init__(self, url, modele, consigne, rapide=False):
        self.url = url.rstrip("/") + "/api/generate"
        self.modele = modele
        self.consigne = consigne
        self.rapide = rapide
        self.appels = 0

    def decider(self, jpeg, historique, capteur=""):
        self.appels += 1
        options = ([OPTION_GAUCHE, OPTION_DROITE] if self.appels % 2
                   else [OPTION_DROITE, OPTION_GAUCHE])          # anti-biais
        prompt = self.consigne.format(historique=", ".join(historique) or "aucune",
                                      options="\n".join(options), capteur=capteur)
        charge = {
            "model": self.modele,
            "prompt": prompt,
            "images": [base64.b64encode(jpeg).decode("ascii")],
            "stream": False,
            "format": SCHEMA,
            "keep_alive": "15m",
            "options": {"temperature": 0.1, "num_predict": 90 if self.rapide else 140},
        }
        debut = time.time()
        reponse = requests.post(self.url, json=charge, timeout=120)
        reponse.raise_for_status()
        texte = reponse.json().get("response", "")
        latence = time.time() - debut
        try:
            decision = json.loads(texte)
        except json.JSONDecodeError:
            # JSON tronque (raison trop longue) : on recupere ce qu'on peut plutot
            # que de stopper le robot pour une faute de frappe du modele
            import re
            trouve = re.search(r'"action"\s*:\s*"(\w+)"', texte)
            libre_t = re.search(r'"libre"\s*:\s*"(\w+)"', texte)
            action = trouve.group(1) if trouve else "stop"
            return (action if action in ACTIONS else "stop",
                    libre_t.group(1) if libre_t else "?",
                    "(JSON tronque) " + texte[:50].replace("\n", " "), latence)
        action = decision.get("action", "stop")
        libre = decision.get("libre", "?")
        return (action if action in ACTIONS else "stop", libre,
                str(decision.get("raison", "")).strip(), latence)


# ---------------------------------------------------------------------------
# Sources d'images
# ---------------------------------------------------------------------------

class SourcePhotos:

    def __init__(self, robot):
        self.robot = robot
        self.flux = None

    def image(self):
        chemin = self.robot.photo(DOSSIER)
        if not chemin:
            return None, None
        with open(chemin, "rb") as fichier:
            return fichier.read(), chemin

    def age(self):
        return 0.0

    def fermer(self):
        pass


class SourceFlux:

    def __init__(self, robot, resolution):
        from flux import FluxVideo
        self.flux = FluxVideo(robot, resolution=resolution)
        if not self.flux.demarrer():
            raise RuntimeError("flux video indisponible")

    def image(self):
        jpeg = self.flux.derniere(AGE_IMAGE_MAX_S)
        if jpeg is None:
            return None, None
        return jpeg, self.flux.enregistrer(jpeg, DOSSIER)

    def age(self):
        return self.flux.age() or 0.0

    def fermer(self):
        self.flux.arreter()


# ---------------------------------------------------------------------------
# Journal
# ---------------------------------------------------------------------------

class Journal:

    def __init__(self):
        if not os.path.isdir(DOSSIER):
            os.makedirs(DOSSIER)
        self.chemin = os.path.join(DOSSIER, "journal.csv")
        nouveau = not os.path.exists(self.chemin)
        self.fichier = open(self.chemin, "a")
        self.csv = csv.writer(self.fichier)
        if nouveau:
            self.csv.writerow(["horodatage", "mode", "n", "image", "age_s",
                               "reflexe_g", "reflexe_c", "reflexe_d", "bloque",
                               "libre", "action", "raison", "latence_s",
                               "batterie", "executee", "gaz", "gaz_alerte",
                               "temp", "chaleur_alerte", "vapeur", "vapeur_alerte"])
        self.latences = []

    def ecrire(self, mode, n, image, age, mesure, bloque, libre, action, raison,
               latence, batterie, executee, detecteurs=None):
        self.latences.append(latence)
        m = mesure or {}
        par_nom = {d.NOM: d for d in (detecteurs or [])}
        def col(nom):
            d = par_nom.get(nom)
            if not d or not d.present or d.lecture is None:
                return "", ""
            return "%.1f" % d.lecture, d.alerte
        self.csv.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), mode, n, image,
                           "%.2f" % age,
                           "%.2f" % m["gauche"] if m else "", "%.2f" % m["centre"] if m else "",
                           "%.2f" % m["droite"] if m else "", bloque,
                           libre, action, raison, "%.2f" % latence, batterie, executee,
                           *col("gaz"), *col("chaleur"), *col("vapeur")])
        self.fichier.flush()

    def fermer(self):
        self.fichier.close()
        if self.latences:
            print("latence modele : moyenne %.1fs, min %.1fs, max %.1fs sur %d decisions"
                  % (sum(self.latences) / len(self.latences), min(self.latences),
                     max(self.latences), len(self.latences)))


# ---------------------------------------------------------------------------
# Anti-blocage
# ---------------------------------------------------------------------------

class AntiBlocage:

    def __init__(self):
        self.rotations = 0
        self.dernier_sens = None

    def observer(self, action):
        if action in ("gauche", "droite"):
            self.rotations += 1
            self.dernier_sens = action
        elif action == "avance":
            self.rotations = 0

    def corriger(self, action):
        if self.rotations >= ROTATIONS_AVANT_DEMI_TOUR:
            self.rotations = 0
            return "demi_tour", "%d rotations sans progres : demi-tour" % ROTATIONS_AVANT_DEMI_TOUR
        if self.rotations == ROTATIONS_AVANT_RECUL and action in ("gauche", "droite"):
            self.rotations += 1
            return "recule", "%d rotations sans progres : je recule" % ROTATIONS_AVANT_RECUL
        return action, None

    def sens_oppose(self):
        return "droite" if self.dernier_sens == "gauche" else "gauche"


MARCHE_MIN_S = 6.0        # duree de marche avant d'accepter une rotation volontaire
PROFONDEUR_COTE_MIN = 1.2 # un cote doit etre ouvert d'au moins ca pour y tourner
OUVERTURE_NETTE = 1.5     # ... et etre au moins 1,5 x plus profond que l'avant
APPROCHE_M = 1.0          # en dessous : le passage se referme, tourner est legitime


def gouverner(action, libre, reflexe, marche_depuis_s):
    """Rend la decision du modele coherente avec ce qui est MESURE.

    Le reflexe est l'autorite sur la proximite ; le modele propose une
    direction, le gouverneur l'accepte ou la convertit en 'avance'.
    Renvoie (action, motif) ; motif vaut None si rien n'a change.
    """
    if not reflexe or not reflexe.mesure:
        if action in ("gauche", "droite") and marche_depuis_s < MARCHE_MIN_S:
            return "avance", "je marche depuis %.0f s seulement" % marche_depuis_s
        return action, None

    m = reflexe.mesure
    centre = m["centre"]

    if reflexe.bloque:
        if action == "avance":
            return reflexe.cote_libre(), "veto : obstacle a %.2f m, je tourne" % centre
        return action, None

    if action == "recule":
        if centre >= APPROCHE_M:
            return "avance", "%.2f m de libre devant : recul inutile" % centre
        return reflexe.cote_libre(), "%.2f m devant : je tourne plutot que reculer" % centre

    if action in ("gauche", "droite"):
        if centre < APPROCHE_M:                          # le passage se referme
            meilleur = reflexe.cote_libre()
            if meilleur != action:
                return meilleur, "passage a %.2f m : je tourne du cote le plus profond" % centre
            return action, None
        if libre != action:
            return "avance", "rotation incoherente (libre=%s, action=%s)" % (libre, action)
        if m[action] < PROFONDEUR_COTE_MIN:
            return "avance", "cote %s trop ferme (%.1f m)" % (action, m[action])
        if m[action] < OUVERTURE_NETTE * centre:
            return "avance", ("cote %s (%.1f m) pas plus ouvert que devant (%.1f m)"
                              % (action, m[action], centre))
        if marche_depuis_s < MARCHE_MIN_S:
            return "avance", "je marche depuis %.0f s seulement" % marche_depuis_s
        return action, None

    return action, None


# ---------------------------------------------------------------------------
# Tour par tour
# ---------------------------------------------------------------------------

def tour_par_tour(robot, cerveau, source, journal, decisions, confirmer, parle):
    historique, anti = [], AntiBlocage()
    for n in range(1, decisions + 1):
        print("\n=== decision %d/%d  batterie %s%% ===" % (n, decisions, robot.batterie()))
        jpeg, chemin = source.image()
        if jpeg is None:
            print("pas d'image, on arrete")
            return
        action, libre, raison, latence = cerveau.decider(jpeg, historique[-4:])
        print("  modele : libre=%-6s action=%-7s (%.1fs)  %s" % (libre, action, latence, raison))
        action, motif = anti.corriger(action)
        if motif:
            print("  [anti-blocage] %s" % motif)

        executee = False
        if action != "stop":
            if confirmer:
                saisie = input("  Entree = executer, n = ignorer, q = quitter ")
                if saisie.lower() == "q":
                    return
                if saisie.lower() == "n":
                    action = "ignoree"
            if action != "ignoree":
                if parle and raison:
                    robot.dis(raison)
                try:
                    if action == "avance":
                        executee = robot.avance()
                    elif action == "recule":
                        executee = robot.recule()
                    elif action == "demi_tour":
                        executee = robot.tourne(anti.sens_oppose(), pas=3)
                    else:
                        executee = robot.tourne(action)
                    if not executee and robot.en_veille():
                        robot.reveiller()
                except RobotIndisponible as refus:
                    print("  [ARRET] %s" % refus)
                    return
        anti.observer(action)
        historique.append(action)
        journal.ecrire("pas", n, chemin, source.age(), None, False, libre, action,
                       raison, latence, robot.batterie(), executee)
        time.sleep(0.3)


# ---------------------------------------------------------------------------
# Continu
# ---------------------------------------------------------------------------

def continu(robot, cerveau, source, journal, decisions, vitesse, parle, reflexe, periode=1, bras=True, detecteurs=None):
    historique, anti = [], AntiBlocage()
    en_marche = False
    debut_marche = [None]                 # instant ou la marche courante a commence
    executeur = ThreadPoolExecutor(max_workers=1)

    cache_batt = {"t": 0.0, "v": None}
    detecteurs = detecteurs or []
    alertes_traitees = set()          # noms des detecteurs deja traites (demi-tour fait)

    def batterie():
        """Lue au plus une fois toutes les 10 s : chaque appel HTTP au robot
        coute 100-300 ms, et il y en avait deux par decision."""
        if time.time() - cache_batt["t"] > 10:
            cache_batt["v"] = robot.batterie()
            cache_batt["t"] = time.time()
        return cache_batt["v"]

    def marche_depuis():
        return time.time() - debut_marche[0] if (en_marche and debut_marche[0]) else 0.0

    def demarrer_marche():
        if reflexe and (reflexe.bloque or (reflexe.mesure or {}).get("motif")):
            print("  [reflexe] marche refusee : obstacle a %.2f m"
                  % (reflexe.distance_devant() or 0))
            return False
        ok = robot.marche(vitesse, periode=periode)
        if ok and reflexe and reflexe.bloque:           # le frein a parle entre-temps
            robot.marche_stop(se_relever=False)
            print("  [reflexe] marche annulee : frein declenche pendant l'ordre")
            return False
        if not ok and robot.en_veille():
            robot.reveiller()
            ok = robot.marche(vitesse, periode=periode)
        if ok:
            debut_marche[0] = time.time()
        return ok

    dernier_maintien = [0.0]

    def maintenir_marche():
        """Reemet l'ordre de marche chaque seconde tant qu'on avance : si la
        marche s'eteint d'elle-meme, elle repart sans attendre le modele."""
        if time.time() - dernier_maintien[0] > 1.0:
            robot.marche(vitesse, periode=periode, maintien=True, bras=bras)
            dernier_maintien[0] = time.time()

    try:
        for n in range(1, decisions + 1):
            jpeg, chemin = source.image()
            if jpeg is None:
                print("\n[ARRET] image absente ou trop vieille : flux perdu")
                break
            age = source.age()
            capteur = reflexe.resume() if reflexe else ""
            for d in detecteurs:
                if d.resume():
                    capteur = (capteur + " " + d.resume()).strip()

            # decision en arriere-plan + chien de garde
            futur = executeur.submit(cerveau.decider, jpeg, historique[-4:], capteur)
            debut = time.time()
            stoppe_par_delai = False
            while not futur.done():
                time.sleep(0.05)
                if en_marche and not (reflexe and reflexe.bloque):
                    maintenir_marche()
                if en_marche and not stoppe_par_delai and time.time() - debut > DELAI_MODELE_S:
                    print("  [chien de garde] modele muet depuis %.0fs : arret preventif" % DELAI_MODELE_S)
                    robot.marche_stop(se_relever=False)
                    en_marche = False
                    stoppe_par_delai = True
            action, libre, raison, latence = futur.result()

            mesure = reflexe.mesure if reflexe else None
            bloque = bool(reflexe and reflexe.bloque)
            if bloque:
                en_marche = False              # le reflexe a coupe la marche

            print("\n=== %d  batt %s%%  marche=%s depuis %.0fs (etat %s)  image %.2fs ==="
                  % (n, batterie(), en_marche, marche_depuis(), robot.marche_etat(), age))
            if mesure:
                u = reflexe.ultrason.mesure if (reflexe.ultrason and reflexe.ultrason.disponible) else None
                print("  reflexe: g=%.2f  c=%.2f  d=%.2f m  texture %.0f%s%s%s"
                      % (mesure["gauche"], mesure["centre"], mesure["droite"],
                         mesure.get("texture", 0), "  PLAT" if mesure.get("plat") else "",
                         "   ULTRASON %.2f m" % u["centre"] if u else "",
                         "   BLOQUE" if bloque else ""))
            print("  modele : libre=%-6s action=%-7s (%.1fs)  %s" % (libre, action, latence, raison))

            action, motif = anti.corriger(action)
            if motif:
                print("  [anti-blocage] %s" % motif)

            action, motif = gouverner(action, libre, reflexe, marche_depuis())
            if motif:
                print("  [gouverneur] %s -> %s" % (motif, action))

            # alertes environnement : gaz et chaleur -> on s'eloigne (demi-tour,
            # une seule fois par episode) ; vapeur -> on signale seulement
            for d in detecteurs:
                if d.alerte and d.NOM not in alertes_traitees:
                    alertes_traitees.add(d.NOM)
                    if d.NOM in ("gaz", "chaleur"):
                        action = "demi_tour"
                        print("  [%s] alerte (lecture %.1f) : demi-tour" % (d.NOM, d.lecture or 0))
                    else:
                        print("  [%s] alerte (lecture %.1f) : signalee" % (d.NOM, d.lecture or 0))
                elif not d.alerte:
                    alertes_traitees.discard(d.NOM)

            executee = True
            try:
                if action == "avance":
                    if not en_marche or not robot.en_marche():
                        en_marche = demarrer_marche()
                        dernier_maintien[0] = time.time()
                    else:
                        maintenir_marche()
                    executee = en_marche
                elif action in ("gauche", "droite", "demi_tour"):
                    robot.marche_stop()
                    en_marche = False
                    if parle and raison:
                        robot.dis(raison)
                    if action == "demi_tour":
                        executee = robot.tourne(anti.sens_oppose(), pas=3)
                    else:
                        executee = robot.tourne(action)
                    en_marche = demarrer_marche()
                elif action == "recule":
                    robot.marche_stop(se_relever=False)
                    if parle and raison:
                        robot.dis(raison)
                    executee = robot.marche(-abs(vitesse), periode=periode)
                    time.sleep(DUREE_RECUL_S)
                    robot.marche_stop(se_relever=False)
                    en_marche = False
                else:                                       # stop
                    if en_marche:
                        robot.marche_stop(se_relever=False)
                        en_marche = False
                    if parle and raison:
                        robot.dis(raison)
                if robot.est_tombe():
                    raise RobotIndisponible("chute detectee")
            except RobotIndisponible as refus:
                print("  [ARRET] %s" % refus)
                break

            anti.observer(action)
            historique.append(action)
            journal.ecrire("continu", n, chemin, age, mesure, bloque, libre, action,
                           raison, latence, batterie(), executee, detecteurs)
    finally:
        robot.marche_stop()
        executeur.shutdown(wait=False)


# ---------------------------------------------------------------------------

def demarrer_reflexe(source, robot, seuil, cadence=3.0, device=None, url_ultrason=None):
    """Renvoie un Reflexe actif, ou None (avec explication) si impossible."""
    if Reflexe is None:
        print("[reflexe] indisponible : %s\n          -> pip install torch transformers pillow numpy" % ERREUR_REFLEXE)
        return None
    if source.flux is None:
        print("[reflexe] necessite le flux video, pas --photos")
        return None
    ultrason = None
    if url_ultrason:
        ultrason = Ultrason(url_ultrason, robot, seuil=seuil)
        ultrason.start()
        print("[ultrason] sondage de %s ..." % url_ultrason)
        time.sleep(1.0)
        if not ultrason.disponible:
            print("[ultrason] aucun serveur : le frein reposera sur la profondeur seule"
                  " (voir ultrason_serveur.py)")
    try:
        reflexe = Reflexe(source.flux, robot, seuil=seuil, cadence_hz=cadence,
                          device=device, ultrason=ultrason)
    except ModeleAbsent as erreur:
        print("[reflexe] %s" % erreur)
        return None
    reflexe.start()
    print("[reflexe] attente de la premiere mesure...")
    reflexe.pret.wait(timeout=30)
    if not reflexe.mesure:
        print("[reflexe] aucune mesure en 30 s : desactive")
        reflexe.arreter()
        return None
    print("[reflexe] actif : seuil %.2f m, %.0f ms par image" % (seuil, reflexe.mesure["ms"]))
    return reflexe


def main():
    analyseur = argparse.ArgumentParser(description=__doc__,
                                        formatter_class=argparse.RawDescriptionHelpFormatter)
    analyseur.add_argument("ip")
    analyseur.add_argument("--continu", action="store_true")
    analyseur.add_argument("--rapide", action="store_true", help="flux 320x240, modele 3b")
    analyseur.add_argument("--vitesse", type=int, default=2)
    analyseur.add_argument("--periode", type=int, default=1,
                           help="param. period du gait (1-5), voir robot.py marche")
    analyseur.add_argument("--sans-bras", action="store_true",
                           help="bras immobiles pendant la marche (DECONSEILLE : le robot derive)")
    analyseur.add_argument("--marche", choices=("gait", "motion"), default="gait",
                           help="gait = generateur STM32 ; motion = animation 'walk' integree")
    analyseur.add_argument("--seuil", type=float, default=0.40, help="frein reflexe, en metres")
    analyseur.add_argument("--sans-reflexe", action="store_true", help="DECONSEILLE")
    analyseur.add_argument("--cadence", type=float, default=3.0,
                           help="images/s analysees par le reflexe (defaut 3)")
    analyseur.add_argument("--reflexe-cpu", action="store_true",
                           help="profondeur sur CPU : laisse le GPU au modele de langage")
    analyseur.add_argument("--ultrason", default="auto",
                           help="URL du serveur ultrason (defaut http://IP:8080), 'non' pour ignorer")
    analyseur.add_argument("--sans-alertes", "--sans-gaz", action="store_true",
                           help="ignore les capteurs d'environnement (gaz, chaleur, vapeur)")
    analyseur.add_argument("--gaz-ratio", type=float, default=1.4,
                           help="alerte gaz au-dessus de repos x ratio (defaut 1.4)")
    analyseur.add_argument("--chaleur-delta", type=float, default=5.0,
                           help="alerte chaleur au-dessus de ambiante + N degres (defaut 5)")
    analyseur.add_argument("--vapeur-seuil", type=float, default=300.0,
                           help="alerte vapeur au-dessus de cette lecture brute (defaut 300)")
    analyseur.add_argument("--photos", action="store_true")
    analyseur.add_argument("--confirmer", action="store_true")
    analyseur.add_argument("--parle", action="store_true")
    analyseur.add_argument("--ollama", default="http://localhost:11434")
    analyseur.add_argument("--modele", default=None)
    analyseur.add_argument("--resolution", default=None)
    analyseur.add_argument("--decisions", type=int, default=200)
    options = analyseur.parse_args()

    modele = options.modele or ("qwen2.5vl:3b" if options.rapide else "qwen2.5vl")
    resolution = options.resolution or ("320x240" if options.rapide else "640x480")

    try:
        modeles = requests.get(options.ollama.rstrip("/") + "/api/tags", timeout=5).json()
        noms = [m["name"] for m in modeles.get("models", [])]
        if not any(n.startswith(modele) for n in noms):
            sys.exit("modele %r absent d'Ollama (%s). -> ollama pull %s" % (modele, noms, modele))
    except requests.RequestException as erreur:
        sys.exit("Ollama injoignable sur %s : %s" % (options.ollama, erreur))

    cerveau = Cerveau(options.ollama, modele,
                      CONSIGNE_CONTINU if options.continu else CONSIGNE_PAS, options.rapide)
    journal = Journal()
    print("modele %s, flux %s, mode %s" % (modele, resolution,
                                          "continu" if options.continu else "tour par tour"))

    with Yanshee(options.ip, strict=True) as robot:
        robot.mode_marche = options.marche
        print("mode de marche :", options.marche)
        if robot.reference_debout is None:
            sys.exit("pas de calibration.json : lancez d'abord robot.py IP calibrer")
        while robot.en_veille():
            print("\nRobot en mode economie d'energie.")
            if robot.reveiller():
                break
            input("Appui court sur le bouton poitrine, puis Entree ")

        source, reflexe, detecteurs = None, None, []
        try:
            if options.photos:
                source = SourcePhotos(robot)
            else:
                try:
                    source = SourceFlux(robot, resolution)
                except RuntimeError as erreur:
                    print("[flux] %s -> repli sur les photos" % erreur)
                    source = SourcePhotos(robot)

            if options.continu and not options.sans_reflexe:
                if options.ultrason == "non":
                    url_ultrason = None
                elif options.ultrason == "auto":
                    url_ultrason = "http://%s:8080" % options.ip
                else:
                    url_ultrason = options.ultrason
                reflexe = demarrer_reflexe(source, robot, options.seuil, options.cadence,
                                           "cpu" if options.reflexe_cpu else None, url_ultrason)
                if reflexe is None:
                    print("\n*** SANS REFLEXE, LE ROBOT NE FREINE PAS DEVANT LES OBSTACLES ***")
                    if input("Continuer quand meme ? (o/N) ").lower() != "o":
                        return

            detecteurs = []
            if options.continu and not options.sans_alertes and Capteurs is not None \
                    and options.ultrason != "non":
                capteurs = Capteurs(url_ultrason)
                capteurs.start()
                time.sleep(1.0)
                if not capteurs.disponible:
                    capteurs.arreter()
                    print("[capteurs] serveur muet : pas d'alertes environnement")
                else:
                    couleurs = {"gaz": "red", "chaleur": "red", "vapeur": "blue"}

                    def faire_alerte(d):
                        def _alerte(valeur):
                            robot.yeux(couleurs[d.NOM], "blink")
                            robot.bouton(couleurs[d.NOM], "blink")
                            robot.dis(d.phrase())
                        return _alerte

                    def fin_alerte():
                        if not any(x.alerte for x in detecteurs):
                            robot.yeux("blue", "on")
                            robot.bouton("white", "on")

                    seuils = {"gaz": options.gaz_ratio, "chaleur": options.chaleur_delta,
                              "vapeur": options.vapeur_seuil}
                    for D in DETECTEURS:
                        if capteurs.valeur(D.CLE) is None:
                            print("[%s] cle '%s' absente : non branche ou pas dans le sketch" % (D.NOM, D.CLE))
                            continue
                        d = D(capteurs, seuil_alerte=seuils[D.NOM], sur_fin=fin_alerte)
                        d.sur_alerte = faire_alerte(d)
                        d.start()
                        detecteurs.append(d)
                    if detecteurs:
                        print("[capteurs] detecteurs actifs : %s (calibration en cours, le robot peut demarrer)"
                              % ", ".join(d.NOM for d in detecteurs))
                    else:
                        capteurs.arreter()

            print("\nRobot debout, sol degage, une main prete. Ctrl+C pour arreter.")
            if options.continu:
                continu(robot, cerveau, source, journal, options.decisions,
                        options.vitesse, options.parle, reflexe, options.periode,
                        not options.sans_bras, detecteurs)
            else:
                tour_par_tour(robot, cerveau, source, journal, options.decisions,
                              options.confirmer, options.parle)
        except KeyboardInterrupt:
            print("\ninterrompu")
        finally:
            for d in detecteurs:
                d.arreter()
            if detecteurs:
                detecteurs[0].capteurs.arreter()
            if reflexe:
                reflexe.arreter()
            if source:
                source.fermer()
            journal.fermer()
    print("journal :", journal.chemin)


if __name__ == "__main__":
    main()
