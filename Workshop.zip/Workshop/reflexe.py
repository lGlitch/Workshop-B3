#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
reflexe.py - boucle reflexe : freine devant un obstacle, sans modele de langage

Un thread lit le flux video, estime la profondeur de chaque image avec
Depth Anything V2 (version metrique interieure, ~25 M de parametres), decoupe
l'image en trois bandes verticales et retient la distance la plus proche de
chaque bande. Si le centre passe sous le seuil, il ARRETE le robot lui-meme.

INSTALLATION (Mac)
    pip install torch transformers pillow numpy
    python3 reflexe.py --telecharger      # UNE FOIS, avec internet (~100 Mo)
    Ensuite tout fonctionne hors-ligne, sur le hotspot du robot.

CALIBRATION - a faire avant de s'en servir
    python3 reflexe.py IP_ROBOT
        affiche en continu les distances gauche/centre/droite estimees.
        Placez le robot (ou portez-le) a 1 m, 50 cm, 20 cm d'un mur, notez
        les valeurs affichees, et ajustez SEUIL_M ci-dessous si necessaire.
        Pour voir le bruit EN MARCHE : dans un second terminal,
        python3 robot.py IP marche 2 20 , et observez la colonne "bruit".
        Chaque mesure est aussi ecrite dans exploration/reflexe.csv.

USAGE
    from reflexe import Reflexe
    r = Reflexe(flux, robot, seuil=0.40)   # flux : FluxVideo demarre
    r.start()
    r.mesure     -> {"gauche": 1.2, "centre": 0.35, "droite": 0.9, "age": 0.1}
    r.bloque     -> True si le centre est sous le seuil (le robot a ete stoppe)
"""

import io
import os
import sys
import threading
import time


class ModeleAbsent(Exception):
    """Le modele de profondeur n'est pas dans le cache local."""

MODELE = "depth-anything/Depth-Anything-V2-Metric-Indoor-Small-hf"
SEUIL_M = 0.40        # centre en dessous -> frein
MARGE_M = 0.15        # centre au-dessus de seuil+marge -> deblocage
HAUT_ROI = 0.25       # on ignore le quart superieur (plafond, murs lointains)
BAS_ROI = 0.75        # ... et le quart inferieur (le SOL juste devant les pieds,
                      # qui est reellement a 30-40 cm et rentre dans l'image a
                      # chaque pas quand le corps tangue)
SEUIL_PLAT_M = 0.90   # trois bandes egales (mur) et centre sous ca -> frein
TOLERANCE_PLAT = 0.15 # "egales" = ecart max < 15 % du centre
SEUIL_TEXTURE = 12.0  # ecart-type des gris (0-255) sous lequel l'image est uniforme
TEXTURE_FIABLE = 20.0 # ... et en dessous de ca on ne LEVE pas le frein : nez contre un
                      # mur blanc, l'estimateur lit "4 m" et relacherait tout
FENETRE = 4           # filtre temporel : images conservees
VOTES = 3             # ... dont au moins VOTES sous le seuil pour freiner
FICHIER_CSV = "exploration/reflexe.csv"
PERCENTILE = 10       # "distance proche" d'une bande = 10e percentile de ses pixels
LARGEUR_ENTREE = 320  # les images sont reduites a cette largeur avant estimation


class Ultrason(threading.Thread):
    """Interroge ultrason_serveur.py (sur le robot) a 10 Hz et freine seul.

    C'est le frein PRINCIPAL quand il est present : un HC-SR04 ne se laisse
    pas tromper par un mur blanc. Deux lectures consecutives sous le seuil
    declenchent, deux au-dessus de seuil+marge relachent.
    """

    def __init__(self, url, robot=None, seuil=SEUIL_M, frein=True, verbeux=True):
        super().__init__(daemon=True)
        self.url = url.rstrip("/") + "/distance"
        self.robot = robot
        self.seuil = seuil
        self.frein = frein and robot is not None
        self.verbeux = verbeux
        self.mesure = None            # {"centre","gauche","droite","age"} en m
        self.bloque = False
        self.disponible = False
        self._votes = []
        self._arret = threading.Event()

    def sonder(self):
        import requests
        try:
            reponse = requests.get(self.url, timeout=0.5)
            m = reponse.json()
        except Exception:
            return None
        if m.get("perime") or m.get("centre") is None:
            return None
        return m

    def run(self):
        import requests
        echecs = 0
        while not self._arret.is_set():
            debut = time.time()
            m = self.sonder()
            if m is None:
                echecs += 1
                if echecs == 20 and self.verbeux:
                    print("[ultrason] pas de mesure depuis 2 s : profondeur seule")
                if echecs >= 20:
                    self.disponible = False
                self._arret.wait(0.1)
                continue
            if not self.disponible and self.verbeux:
                print("[ultrason] actif : %.2f m devant" % m["centre"])
            self.disponible = True
            echecs = 0
            self.mesure = m
            c = m["centre"]
            self._votes = (self._votes + [c])[-2:]
            if len(self._votes) == 2 and all(v < self.seuil for v in self._votes):
                if not self.bloque and self.verbeux:
                    print("[ultrason] OBSTACLE a %.2f m -> FREIN" % c)
                self.bloque = True
                if self.frein:
                    self.robot.marche_stop(se_relever=False)
            elif self.bloque and len(self._votes) == 2 and all(
                    v > self.seuil + MARGE_M for v in self._votes):
                self.bloque = False
                if self.verbeux:
                    print("[ultrason] degage (%.2f m)" % c)
            reste = 0.1 - (time.time() - debut)
            if reste > 0:
                self._arret.wait(reste)

    def arreter(self):
        self._arret.set()


class Reflexe(threading.Thread):

    def __init__(self, flux, robot=None, seuil=SEUIL_M, frein=True, verbeux=True,
                 cadence_hz=3.0, device=None, ultrason=None):
        """cadence_hz : images analysees par seconde (le reste du temps, le GPU
        est laisse au modele de langage). device : "mps", "cuda", "cpu" ou None
        (auto)."""
        super().__init__(daemon=True)
        self.flux = flux
        self.robot = robot
        self.seuil = seuil
        self.cadence_hz = cadence_hz
        self.device = device
        self.ultrason = ultrason      # instance Ultrason demarree, ou None
        self.frein = frein and robot is not None
        self.verbeux = verbeux
        self.mesure = None
        self._bloque_profondeur = False
        self.pret = threading.Event()
        self._arret = threading.Event()
        self._historique = []          # derniers "centre", pour le vote
        self._csv = None
        self._charger_modele()

    def _journaliser(self, mesure):
        try:
            if self._csv is None:
                dossier = os.path.dirname(FICHIER_CSV)
                if dossier and not os.path.isdir(dossier):
                    os.makedirs(dossier)
                nouveau = not os.path.exists(FICHIER_CSV)
                self._csv = open(FICHIER_CSV, "a")
                if nouveau:
                    self._csv.write("horodatage,gauche,centre,droite,texture,plat,motif,ms,age,bloque\n")
            self._csv.write("%.3f,%.3f,%.3f,%.3f,%.1f,%d,%s,%.0f,%.2f,%d\n"
                            % (time.time(), mesure["gauche"], mesure["centre"],
                               mesure["droite"], mesure["texture"], mesure["plat"],
                               mesure.get("motif", ""), mesure["ms"], mesure["age"], self._bloque_profondeur))
            self._csv.flush()
        except OSError:
            pass

    # -- modele -------------------------------------------------------------

    def _charger_modele(self):
        """Charge le modele DEPUIS LE CACHE LOCAL uniquement.

        Sur le reseau du robot (hotspot) il n'y a souvent pas d'internet, et
        transformers passerait une minute a reessayer. On force le mode
        hors-ligne ; si le modele n'est pas en cache, on echoue tout de suite
        avec la marche a suivre. Telechargement : python3 reflexe.py --telecharger
        """
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"
        try:
            import numpy as np
            import torch
            from PIL import Image
            from transformers import pipeline
        except ImportError as erreur:
            raise ModeleAbsent("dependance manquante (%s)\n"
                               "  -> pip install torch transformers pillow numpy" % erreur)
        self._np, self._Image = np, Image
        device = self.device
        if device is None:
            if torch.backends.mps.is_available():
                device = "mps"
            elif torch.cuda.is_available():
                device = "cuda"
            else:
                device = "cpu"
        if self.verbeux:
            print("[reflexe] chargement de %s (cache local) sur %s..." % (MODELE, device))
        debut = time.time()
        try:
            self._pipe = pipeline("depth-estimation", model=MODELE, device=device)
        except (OSError, ValueError) as erreur:
            raise ModeleAbsent(
                "modele de profondeur absent du cache local.\n"
                "  Connectez le Mac a un reseau AVEC internet (wifi de l'ecole),\n"
                "  lancez une fois :  python3 reflexe.py --telecharger\n"
                "  puis revenez sur le hotspot du robot.\n  (%s)" % str(erreur).splitlines()[0])
        if self.verbeux:
            print("[reflexe] pret en %.1f s" % (time.time() - debut))

    def estimer(self, jpeg):
        """Distances (m) proches par bande : {"gauche", "centre", "droite", "ms"}."""
        np = self._np
        image = self._Image.open(io.BytesIO(jpeg)).convert("RGB")
        if image.width > LARGEUR_ENTREE:
            image = image.resize((LARGEUR_ENTREE,
                                  int(image.height * LARGEUR_ENTREE / image.width)))
        debut = time.time()
        sortie = self._pipe(image)
        profondeur = sortie["predicted_depth"]
        if hasattr(profondeur, "detach"):
            profondeur = profondeur.detach().cpu().numpy()
        profondeur = np.squeeze(profondeur)
        hauteur, largeur = profondeur.shape
        zone = profondeur[int(hauteur * HAUT_ROI):int(hauteur * BAS_ROI), :]
        tiers = largeur // 3
        bandes = {
            "gauche": zone[:, :tiers],
            "centre": zone[:, tiers:2 * tiers],
            "droite": zone[:, 2 * tiers:],
        }
        mesure = {nom: float(np.percentile(b, PERCENTILE)) for nom, b in bandes.items()}

        # texture de la bande mediane de l'IMAGE (pas de la profondeur) : une
        # surface unie tres proche donne un ecart-type des gris quasi nul, et
        # c'est precisement la ou l'estimateur de profondeur invente une distance
        gris = np.asarray(image.convert("L"), dtype=float)
        h_img = gris.shape[0]
        mesure["texture"] = float(gris[int(h_img * HAUT_ROI):int(h_img * BAS_ROI), :].std())

        # trois bandes egales = surface plane qui remplit le champ (mur)
        valeurs = (mesure["gauche"], mesure["centre"], mesure["droite"])
        mesure["plat"] = (max(valeurs) - min(valeurs)) < TOLERANCE_PLAT * max(mesure["centre"], 0.05)

        mesure["ms"] = (time.time() - debut) * 1000
        return mesure

    def _telemetre_actif(self):
        return bool(self.ultrason and self.ultrason.disponible)

    def _danger(self, m):
        """Motif de danger pour cette image, ou None.

        Avec un telemetre ultrason actif, la profondeur ne freine plus que sur
        sa propre distance (secours) : "mur plat" et "surface uniforme"
        etaient des palliatifs a l'absence de telemetre, et ne font que du
        bruit quand il est la.
        """
        c = m["centre"]
        if c < self.seuil:
            return "distance"
        if self._telemetre_actif():
            return None
        if m["plat"] and c < SEUIL_PLAT_M:
            return "mur plat"
        if m["texture"] < SEUIL_TEXTURE and m["plat"]:
            return "surface uniforme"          # quelle que soit la distance estimee
        return None

    def _sur(self, m):
        """Vrai si l'image est franchement degagee (pour lever le frein)."""
        c = m["centre"]
        if self._telemetre_actif():
            return c > self.seuil + MARGE_M
        return (c > self.seuil + MARGE_M
                and not (m["plat"] and c < SEUIL_PLAT_M + MARGE_M)
                and m["texture"] >= TEXTURE_FIABLE)

    # -- thread -------------------------------------------------------------

    def run(self):
        intervalle = 1.0 / max(0.5, self.cadence_hz)
        while not self._arret.is_set():
            debut_cycle = time.time()
            jpeg = self.flux.derniere(age_max_s=1.5)
            if jpeg is None:
                time.sleep(0.05)
                continue
            try:
                mesure = self.estimer(jpeg)
            except Exception as erreur:
                print("[reflexe] erreur d'estimation : %s" % erreur)
                time.sleep(0.5)
                continue
            mesure["age"] = self.flux.age() or 0.0
            self.mesure = mesure
            self.pret.set()

            centre = mesure["centre"]
            motif = self._danger(mesure)
            mesure["motif"] = motif or ""
            self._historique = (self._historique + [(motif, self._sur(mesure))])[-FENETRE:]
            en_danger = sum(1 for mo, _ in self._historique if mo)
            au_dessus = sum(1 for _, ok in self._historique if ok)
            self._journaliser(mesure)

            if en_danger >= VOTES:
                if not self._bloque_profondeur:
                    self._bloque_profondeur = True
                    if self.verbeux:
                        motifs = sorted({mo for mo, _ in self._historique if mo})
                        print("[reflexe] OBSTACLE a %.2f m (g=%.2f d=%.2f, texture %.0f) [%s] -> FREIN"
                              % (centre, mesure["gauche"], mesure["droite"],
                                 mesure["texture"], ", ".join(motifs)))
                if self.frein:
                    # on re-stoppe a chaque passage tant que c'est bloque : si la
                    # boucle principale a relance la marche sur une vieille
                    # decision, le robot ne fait qu'un pas.
                    self.robot.marche_stop(se_relever=False)
            elif self._bloque_profondeur and au_dessus >= VOTES:
                self._bloque_profondeur = False
                if self.verbeux:
                    print("[reflexe] degage (%.2f m)" % centre)
            # on laisse le GPU respirer entre deux images
            reste = intervalle - (time.time() - debut_cycle)
            if reste > 0:
                self._arret.wait(reste)

    def arreter(self):
        self._arret.set()
        if self.ultrason:
            self.ultrason.arreter()

    @property
    def bloque(self):
        """Frein actif : ultrason (prioritaire) OU profondeur."""
        if self.ultrason and self.ultrason.disponible:
            return self.ultrason.bloque or self._bloque_profondeur
        return self._bloque_profondeur

    def distance_devant(self):
        """Meilleure estimation de la distance frontale (m) : ultrason si dispo."""
        if self.ultrason and self.ultrason.disponible and self.ultrason.mesure:
            return self.ultrason.mesure["centre"]
        return self.mesure["centre"] if self.mesure else None

    def cote_libre(self):
        """'gauche' ou 'droite' : la bande laterale la plus profonde."""
        u = self.ultrason.mesure if (self.ultrason and self.ultrason.disponible) else None
        if u and u.get("gauche") is not None and u.get("droite") is not None:
            return "gauche" if u["gauche"] >= u["droite"] else "droite"
        if not self.mesure:
            return "gauche"
        return "gauche" if self.mesure["gauche"] >= self.mesure["droite"] else "droite"

    def resume(self):
        """Texte pour le modele de langage : QUALITATIF, sans chiffres.

        Le modele prend les nombres au pied de la lettre ("0,8 m devant" ->
        "il y a un meuble, je tourne"). On ne lui dit que ce qu'il doit savoir.
        """
        if self.bloque:
            return ("Capteurs : OBSTACLE PROCHE DEVANT, le robot est arrete. Avancer est"
                    " impossible ; le cote le plus degage est %s." % self.cote_libre())
        m = self.mesure
        if not m:
            return "Capteurs : pas encore de mesure."
        d = self.distance_devant()
        if d is not None and d < 1.0:
            return "Capteurs : le passage devant se referme ; cote le plus degage : %s." % self.cote_libre()
        if m.get("plat") and m["centre"] < 2.0:
            return "Capteurs : voie libre devant ; une surface plane (mur ?) occupe le champ."
        return "Capteurs : voie libre devant."


# ---------------------------------------------------------------------------

def calibration(ip):
    from robot import Yanshee
    from flux import FluxVideo
    robot = Yanshee(ip, gestion_chute=False)
    ultrason = Ultrason("http://%s:8080" % ip, robot=None, frein=False)
    ultrason.start()
    with FluxVideo(robot, resolution="320x240") as flux:
        if not flux.derniere(10):
            sys.exit("pas de flux video")
        reflexe = Reflexe(flux, robot=None, frein=False, ultrason=ultrason)
        reflexe.start()
        print("\nPlacez le robot face a un mur a 1 m, puis 50 cm, puis 20 cm.")
        print("Mettez aussi une main devant la camera. Ctrl+C pour finir.\n")
        recents = []
        try:
            while True:
                m = reflexe.mesure
                if m:
                    recents = (recents + [m["centre"]])[-10:]
                    moyenne = sum(recents) / len(recents)
                    ecart = (sum((c - moyenne) ** 2 for c in recents) / len(recents)) ** 0.5
                    u = ultrason.mesure if ultrason.disponible else None
                    print("  g %5.2f  CENTRE %5.2f  d %5.2f m   texture %5.1f%s   "
                          "ULTRASON %s   (%3.0f ms, bruit +/-%.2f)%s"
                          % (m["gauche"], m["centre"], m["droite"], m["texture"],
                             " PLAT" if m["plat"] else "     ",
                             "%5.2f m" % u["centre"] if u else "  ---  ", m["ms"], ecart,
                             "   <-- FREIN [%s]" % reflexe._danger(m) if reflexe._danger(m) else ""))
                time.sleep(0.5)
        except KeyboardInterrupt:
            reflexe.arreter()
            ultrason.arreter()
            print("\nSi les valeurs a 20 cm sont au-dessus de %.2f, montez SEUIL_M ;"
                  " si celles a 1 m sont en dessous, baissez-le." % SEUIL_M)
            print("Face a un mur blanc a 30 cm, 'texture' doit passer sous %.0f : sinon"
                  " montez SEUIL_TEXTURE. En espace ouvert elle doit rester bien au-dessus."
                  % SEUIL_TEXTURE)


def telecharger():
    """A lancer une fois, avec internet : met le modele (~100 Mo) en cache."""
    os.environ.pop("HF_HUB_OFFLINE", None)
    os.environ.pop("TRANSFORMERS_OFFLINE", None)
    from transformers import pipeline
    print("telechargement de %s..." % MODELE)
    pipeline("depth-estimation", model=MODELE, device="cpu")
    print("OK : modele en cache. Vous pouvez repasser sur le hotspot du robot.")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    if sys.argv[1] == "--telecharger":
        telecharger()
    else:
        try:
            calibration(sys.argv[1])
        except ModeleAbsent as erreur:
            sys.exit("\n[reflexe] %s" % erreur)
